enum StatusRequest{
  non ,
  loading,
  success ,
  failure ,
  serverFailure,
  noData,
}